// app.js (module)
const form = document.getElementById('searchForm');
const input = document.getElementById('usernameInput');
const statusEl = document.getElementById('status');
const resultEl = document.getElementById('result');
const profileCard = document.getElementById('profileCard');
const repoList = document.getElementById('repoList');

const GITHUB_API = 'https://api.github.com';

// small in-memory cache to avoid repeated requests during a session
const cache = new Map();

function setStatus(message, { isError = false, showSpinner = false } = {}) {
  statusEl.innerHTML = `${showSpinner ? '<span class="spinner" aria-hidden="true"></span>&nbsp;' : ''}${escapeHtml(message)}`;
  statusEl.style.color = isError ? '#ffb4b4' : '';
}

function clearStatus() {
  statusEl.textContent = '';
}

function escapeHtml(str) {
  if (!str) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}

async function fetchJson(url) {
  const res = await fetch(url, {
    headers: {
      Accept: 'application/vnd.github.v3+json',
      // Add a custom User-Agent-like header (optional)
      'X-Requested-With': 'GitHub-Profile-Finder'
    }
  });
  if (!res.ok) {
    const text = await res.text();
    const err = new Error('Request failed');
    err.status = res.status;
    err.body = text;
    throw err;
  }
  return await res.json();
}

async function getUser(username) {
  const url = `${GITHUB_API}/users/${encodeURIComponent(username)}`;
  if (cache.has(url)) return cache.get(url);
  const data = await fetchJson(url);
  cache.set(url, data);
  return data;
}

async function getRepos(username) {
  // fetch up to 100 repos, then sort on client for top-starred
  const url = `${GITHUB_API}/users/${encodeURIComponent(username)}/repos?per_page=100`;
  if (cache.has(url)) return cache.get(url);
  const data = await fetchJson(url);
  cache.set(url, data);
  return data;
}

function renderProfile(user) {
  resultEl.hidden = false;
  profileCard.innerHTML = `
    <div class="profile-top">
      <img class="avatar" src="${escapeHtml(user.avatar_url)}" alt="${escapeHtml(user.login)}'s avatar" />
      <div>
        <div class="profile-name">${escapeHtml(user.name || user.login)}</div>
        <div class="profile-meta">@${escapeHtml(user.login)} • ${escapeHtml(user.location || '')}</div>
        <div class="profile-meta"><a href="${escapeHtml(user.html_url)}" target="_blank" rel="noopener">View on GitHub</a></div>
      </div>
    </div>
    <div class="profile-bio">${escapeHtml(user.bio || '')}</div>
    <div class="profile-stats">
      <div class="stat"><strong>${user.followers}</strong><div>Followers</div></div>
      <div class="stat"><strong>${user.following}</strong><div>Following</div></div>
      <div class="stat"><strong>${user.public_repos}</strong><div>Repos</div></div>
    </div>
  `;
}

function renderRepos(repos) {
  repoList.innerHTML = '';
  if (!repos || repos.length === 0) {
    repoList.innerHTML = `<li class="repo"><div class="left"><div class="meta">No repositories found.</div></div></li>`;
    return;
  }
  for (const r of repos) {
    const li = document.createElement('li');
    li.className = 'repo';
    li.innerHTML = `
      <div class="left">
        <a href="${escapeHtml(r.html_url)}" target="_blank" rel="noopener">${escapeHtml(r.name)}</a>
        <div class="meta">${escapeHtml(r.description || '')}</div>
      </div>
      <div class="stats">
        <div title="Stars">★ ${r.stargazers_count}</div>
        <div title="Forks">⎇ ${r.forks_count}</div>
      </div>
    `;
    repoList.appendChild(li);
  }
}

function getTopRepos(repos, limit = 10) {
  return repos
    .slice()
    .sort((a, b) => b.stargazers_count - a.stargazers_count)
    .slice(0, limit);
}

async function search(username) {
  if (!username || !username.trim()) {
    setStatus('Please enter a GitHub username.', { isError: true });
    return;
  }
  username = username.trim();
  setStatus(`Looking up ${username}...`, { showSpinner: true });
  resultEl.hidden = true;
  try {
    const user = await getUser(username);
    renderProfile(user);

    setStatus('Loading repositories...', { showSpinner: true });
    const repos = await getRepos(username);
    const top = getTopRepos(repos, 10);
    renderRepos(top);

    clearStatus();
  } catch (err) {
    resultEl.hidden = true;
    if (err.status === 404) {
      setStatus(`User "${escapeHtml(username)}" not found.`, { isError: true });
    } else if (err.status === 403) {
      setStatus('API rate limit reached. Try again later or authenticate requests.', { isError: true });
    } else {
      setStatus(`Error: ${escapeHtml(err.message || 'Unknown error')}`, { isError: true });
      console.error(err);
    }
  }
}

form.addEventListener('submit', (ev) => {
  ev.preventDefault();
  search(input.value);
});

// allow Enter from input
input.addEventListener('keydown', (ev) => {
  if (ev.key === 'Enter') {
    ev.preventDefault();
    search(input.value);
  }
});

// optional: prefill with an example
if (!input.value) {
  input.value = 'octocat';
  // perform an initial search (comment out if you don't want that)
  // search(input.value);
}