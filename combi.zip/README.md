# GitHub Profile Finder

A small client-side project that lets you search for GitHub users and view their profile details and top repositories. Built with vanilla HTML, CSS and JavaScript using async/await to fetch data from the GitHub REST API.

Live demo
- Demo (GitHub Pages): https://<your-username>.github.io/<your-repo-name>  (replace with your live URL)
- Example (if deployed): https://saraloiahsouni89-cyber.github.io/github-profile-finder

Features
- Search GitHub users by username
- Displays avatar, name, location, bio, followers/following and repo count
- Shows top repositories sorted by stars (top 10)
- Async data fetching with fetch + async/await
- Loading indicators and basic error handling (user not found, rate limit)
- Responsive layout and accessible elements

Files
- index.html — app markup
- styles.css — styling and responsive layout
- app.js — async fetching, rendering logic, and UX handling

How to run locally
1. Clone the repo:
   git clone https://github.com/<your-username>/<your-repo-name>.git
2. Open `index.html` in a browser (double-click or use a simple server).
   - Recommended: run a local static server:
     - Python 3: `python -m http.server 8000`
     - Node (npm): `npx http-server` or use VS Code Live Server
3. Visit `http://localhost:8000` (or the port your server uses) and search for a GitHub username.

Notes on rate limits and auth
- The app uses unauthenticated requests to GitHub's public API. Unauthenticated requests are subject to a low rate limit (usually 60 requests/hour per IP).
- To avoid rate limits in development, you can:
  - Use a personal access token (server-side or by injecting it into fetch headers — but never commit tokens to the repo).
  - Implement server-side proxying or authentication.

Customization ideas / next steps
- Add OAuth or token-based authenticated requests to increase rate limits.
- Show pagination for repositories or the full repo list.
- Add sorting and filtering controls (language, forks, last-updated).
- Add caching with IndexedDB or persistent localStorage and cache invalidation.
- Add tests and CI workflow.

License
MIT — feel free to reuse and modify.

Credits
Built with the GitHub REST API. UI inspiration from various profile explorers and personal UIs.